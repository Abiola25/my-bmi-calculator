const readline = require('readline');
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
rl.question("Enter your weight in kg: ", function(weight) {
  rl.question("Enter your height in meters: ", function(height) {
    const bmi = parseFloat(weight) / (parseFloat(height) ** 2);
    console.log("\nYour BMI is: " + bmi.toFixed(2));
    if (bmi < 18.5) {
      console.log("You are underweight.");
    } else if (bmi < 24.9) {
      console.log("You have a normal weight.");
    } else if (bmi < 29.9) {
      console.log("You are overweight.");
    } else {
      console.log("You are obese.");
    }
    rl.close();
  });
});